# Muhammad Taha Bin Rashid — Portfolio

Full Stack Developer, Karachi. Award-style single-page portfolio built with vanilla HTML/CSS/JS, GSAP 3.15 (ScrollTrigger, SplitText, CustomEase), Lenis smooth scroll and a Three.js WebGL portrait.

Live: https://mtahabinrashid.vercel.app

## Structure

```
index.html            page markup
404.html              designed not-found page (Vercel serves it automatically)
css/main.css          design tokens, type ramp, sections, responsive, reduced motion
js/main.js            scroll, loader, hero choreography, signature interactions
js/gl.js              built bundle of src/gl.js (Three.js portrait)      <- do not edit
src/gl.js             WebGL portrait source (flowmap + duotone shader)   <- edit this
vendor/               gsap, ScrollTrigger, SplitText, CustomEase, lenis (pinned, self-hosted)
fonts/                Bricolage Grotesque (wght+wdth), Geist, Geist Mono (variable, self-hosted)
img/ icons/           optimised portrait (webp+jpg), OG image, PWA icons, favicon.svg
```

## Run locally

Any static server works:

```
npx serve .
```

## Editing the WebGL portrait

`js/gl.js` is a minified bundle. After changing `src/gl.js`:

```
npm install
npm run build
```

## Deploy

Static site. Push to GitHub and import in Vercel (no build step needed; `vercel.json` sets cache headers and clean URLs).

## Signature interactions

1. Hero name: each letter's variable-font weight and width respond to cursor distance (touch devices get a slow weight wave).
2. Scroll velocity compresses the type width axis and skews/speeds the stack tickers.
3. Portrait: pointer movement is painted into a flow field that bends the image with a chromatic split; hover tints it to the ember accent.

`prefers-reduced-motion` disables the loader, pins, parallax and WebGL; all content stays readable.
